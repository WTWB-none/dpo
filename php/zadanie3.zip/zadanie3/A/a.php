<?php
// Flight time calculator function
function calculateFlightTime($input)
{
    $lines = explode("\n", trim($input));
    $n = (int) $lines[0];

    $results = [];
    for ($i = 0; $i < $n; $i++) {
        $line = trim($lines[$i + 1]);
        list($departureTime, $departureTimezone, $arrivalTime, $arrivalTimezone) = explode(' ', $line);

        // Convert departure local time to UTC
        $departureDt = DateTime::createFromFormat('d.m.Y_H:i:s', $departureTime);
        $departureUtc = clone $departureDt;
        $departureUtc->modify((-1 * (int) $departureTimezone) . " hours");

        // Convert arrival local time to UTC
        $arrivalDt = DateTime::createFromFormat('d.m.Y_H:i:s', $arrivalTime);
        $arrivalUtc = clone $arrivalDt;
        $arrivalUtc->modify((-1 * (int) $arrivalTimezone) . " hours");

        // Calculate flight duration in seconds
        $flightDuration = $arrivalUtc->getTimestamp() - $departureUtc->getTimestamp();

        $results[] = $flightDuration;
    }

    return implode("\n", $results);
}

// Directory paths
$datDir = "./test";  // Directory containing test files
$ansDir = "./test";  // Directory containing answer files

// Check if directories exist
if (!is_dir($datDir)) {
    echo "Error: Test data directory '$datDir' not found\n";
    exit(1);
}

if (!is_dir($ansDir)) {
    echo "Error: Answer directory '$ansDir' not found\n";
    exit(1);
}

// Get all .dat files
$datFiles = glob("$datDir/*.dat");

if (empty($datFiles)) {
    echo "No .dat files found in '$datDir'\n";
    exit(1);
}

echo "Running tests on " . count($datFiles) . " files...\n";
$allTestsPassed = true;

foreach ($datFiles as $datFile) {
    // Get test case number from filename
    $testNum = basename($datFile, '.dat');
    $ansFile = "$ansDir/$testNum.ans";

    // Check if answer file exists
    if (!file_exists($ansFile)) {
        echo "Warning: Answer file for test $testNum not found\n";
        continue;
    }

    // Read input and expected output
    $input = file_get_contents($datFile);
    $expectedOutput = trim(file_get_contents($ansFile));

    // Calculate actual output
    $actualOutput = calculateFlightTime($input);
    echo $actualOutput;

    // Compare outputs
    if ($actualOutput === $expectedOutput) {
        echo "Test $testNum: PASSED\n";
    } else {
        echo "Test $testNum: FAILED\n";
        echo "Expected: $expectedOutput\n";
        echo "Got:      $actualOutput\n";
        $allTestsPassed = false;
    }
}

if ($allTestsPassed) {
    echo "All tests passed!\n";
} else {
    echo "Some tests failed. Please check the output above.\n";
}

// Main solution that can be used standalone
if (count($argv) > 1 && $argv[1] === 'run') {
    // If script is run with 'run' argument, execute against stdin or input.txt
    $input = file_exists('input.txt') ? file_get_contents('input.txt') : stream_get_contents(STDIN);
    echo calculateFlightTime($input);
}
?>