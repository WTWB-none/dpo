<?php
/**
 * Решение задачи C "Точно в цель"
 * Создание пирамиды продаж на основе данных о целевых действиях пользователей
 */

// Функция для обработки одного тестового файла
function processTestFile($inputFile, $outputFile)
{
    // Считываем данные из файла
    $lines = file($inputFile, FILE_IGNORE_NEW_LINES);

    // Получаем количество целей
    $numGoals = (int) $lines[0];

    // Получаем идентификаторы целей в порядке конверсионного пути
    $goals = [];
    for ($i = 1; $i <= $numGoals; $i++) {
        $goals[] = trim($lines[$i]);
    }

    // Получаем количество событий
    $numEvents = (int) $lines[$numGoals + 1];

    // Считываем события
    $events = [];
    for ($i = $numGoals + 2; $i < $numGoals + 2 + $numEvents; $i++) {
        list($userId, $goalId) = explode(" ", trim($lines[$i]));
        $events[] = [
            'userId' => $userId,
            'goalId' => $goalId
        ];
    }

    // Анализируем конверсионный путь каждого пользователя
    $userPaths = [];
    foreach ($events as $event) {
        $userId = $event['userId'];
        $goalId = $event['goalId'];

        if (!isset($userPaths[$userId])) {
            $userPaths[$userId] = [];
        }

        // Добавляем цель в путь пользователя, если она входит в список наших целей
        if (in_array($goalId, $goals)) {
            $userPaths[$userId][] = $goalId;
        }
    }

    // Подсчитываем количество пользователей, достигших каждой цели в правильной последовательности
    $goalCounts = [];

    foreach ($userPaths as $userId => $path) {
        $lastGoalIndex = -1;
        $reachedGoals = [];

        // Проверяем цели в правильном порядке
        foreach ($path as $goalId) {
            $currentGoalIndex = array_search($goalId, $goals);

            if ($currentGoalIndex === $lastGoalIndex + 1) {
                // Добавляем цель, только если она следует за предыдущей
                $reachedGoals[] = $goalId;
                $lastGoalIndex = $currentGoalIndex;
            } elseif ($currentGoalIndex <= $lastGoalIndex) {
                // Если повторная цель, пропускаем
                continue;
            } else {
                // Если цель не следует за предыдущей, значит путь нарушен
                break;
            }
        }

        // Отмечаем все достигнутые цели для этого пользователя
        foreach ($reachedGoals as $goalId) {
            if (!isset($goalCounts[$goalId])) {
                $goalCounts[$goalId] = 0;
            }
            $goalCounts[$goalId]++;
        }
    }

    // Создаем пирамиду продаж
    createPyramidImage($goals, $goalCounts, $outputFile);
}

// Функция для создания изображения пирамиды продаж
// Функция для создания изображения пирамиды продаж
// Функция для создания изображения пирамиды продаж
// Функция для создания изображения пирамиды продаж
function createPyramidImage($goals, $goalCounts, $outputFile)
{
    // Размеры изображения
    $width = 600;
    $height = 600;

    // Создаем изображение
    $image = imagecreatetruecolor($width, $height);

    // Установка белого фона
    $white = imagecolorallocate($image, 255, 255, 255);
    imagefill($image, 0, 0, $white);

    // Определяем размеры пирамиды
    $marginTop = 50;
    $marginBottom = 50;
    $marginLeft = 100;
    $marginRight = 100;

    $pyramidWidth = $width - $marginLeft - $marginRight;
    $pyramidHeight = $height - $marginTop - $marginBottom;

    // Вычисляем значения для каждой цели
    $values = [];
    foreach ($goals as $goal) {
        $values[] = isset($goalCounts[$goal]) ? $goalCounts[$goal] : 0;
    }

    // Если нет данных, устанавливаем хотя бы одно значение
    if (empty($values) || max($values) == 0) {
        $values = array_fill(0, count($goals), 1);
    }

    // Максимальное значение для нормализации ширины
    $maxValue = max($values);

    // Определяем цвета (по умолчанию используем цвета из изображения для 3 сегментов)
    $defaultColors = [
        imagecolorallocate($image, 255, 0, 0),   // Красный (верх)
        imagecolorallocate($image, 0, 255, 0),   // Зеленый (середина)
        imagecolorallocate($image, 0, 0, 255)    // Синий (низ)
    ];

    $numSegments = count($goals);
    $colors = [];
    for ($i = 0; $i < $numSegments; $i++) {
        if ($numSegments === 3 && $i < 3) {
            $colors[] = $defaultColors[$i]; // Используем цвета из изображения
        } else {
            // Для другого количества сегментов генерируем случайные цвета
            $colors[] = imagecolorallocate(
                $image,
                rand(50, 200),
                rand(50, 200),
                rand(50, 200)
            );
        }
    }

    // Динамически определяем высоты сегментов (большие вверху, маленькие внизу)
    $segmentHeights = [];
    $totalProportion = 0;
    for ($i = 0; $i < $numSegments; $i++) {
        // Пропорции: верхний сегмент самый большой, нижний самый маленький
        $proportion = ($numSegments - $i) / array_sum(range(1, $numSegments));
        $segmentHeights[] = $proportion;
        $totalProportion += $proportion;
    }
    // Нормализуем пропорции, чтобы их сумма равнялась 1
    for ($i = 0; $i < $numSegments; $i++) {
        $segmentHeights[$i] /= $totalProportion;
    }

    // Начальные координаты для вершины пирамиды (сверху)
    $centerX = $width / 2;
    $currentTopY = $marginTop;

    // Рисуем пирамиду сверху вниз
    for ($i = 0; $i < $numSegments; $i++) {
        $segmentHeight = $pyramidHeight * $segmentHeights[$i];
        $currentBottomY = $currentTopY + $segmentHeight;

        // Вычисляем ширину текущего сегмента пропорционально значению
        $currentWidth = ($values[$i] / $maxValue) * $pyramidWidth;

        // Координаты точек треугольника
        if ($i == $numSegments - 1) {
            // Нижний сегмент - треугольник, сходящийся в точку
            $points = [
                // Вершина (центр нижней точки)
                $centerX,
                $currentBottomY,
                // Левая верхняя точка
                $centerX - $currentWidth / 2,
                $currentTopY,
                // Правая верхняя точка
                $centerX + $currentWidth / 2,
                $currentTopY
            ];
            $numPoints = 3;
        } else {
            // Остальные сегменты - треугольники, сходящиеся к ширине следующего сегмента
            $nextWidth = ($values[$i + 1] / $maxValue) * $pyramidWidth;
            $points = [
                // Вершина (центр нижней точки)
                $centerX,
                $currentBottomY,
                // Левая верхняя точка
                $centerX - $currentWidth / 2,
                $currentTopY,
                // Правая верхняя точка
                $centerX + $currentWidth / 2,
                $currentTopY
            ];
            $numPoints = 3;
        }

        // Преобразуем все координаты в целые числа
        foreach ($points as &$point) {
            $point = (int) $point;
        }

        // Рисуем сегмент
        imagefilledpolygon($image, $points, $numPoints, $colors[$i]);

        // Добавляем черный контур
        $black = imagecolorallocate($image, 0, 0, 0);
        imagepolygon($image, $points, $numPoints, $black);

        // Добавляем текст с названием цели и количеством пользователей (справа от пирамиды)
        $textColor = imagecolorallocate($image, 0, 0, 0);
        $text = "GOAL" . ($i + 1) . ": " . $values[$i]; // Формат текста как в изображении
        $textX = $marginLeft + $pyramidWidth + 20; // Справа от пирамиды
        $textY = (int) ($currentTopY + $segmentHeight / 2);

        $fontSize = 3;
        $textY -= (int) (imagefontheight($fontSize) / 2);
        imagestring($image, $fontSize, $textX, $textY, $text, $textColor);

        // Обновляем верхнюю координату для следующего сегмента
        $currentTopY = $currentBottomY;
    }

    // Сохраняем изображение
    imagepng($image, $outputFile);
    imagedestroy($image);
}

// Обрабатываем все тестовые файлы из директории
$testDir = './test';
$files = glob($testDir . '/*.dat');

foreach ($files as $inputFile) {
    $baseName = basename($inputFile, '.dat');
    $outputFile = $testDir . '/' . $baseName . '.png';

    echo "Processing $inputFile -> $outputFile\n";
    processTestFile($inputFile, $outputFile);
}
?>