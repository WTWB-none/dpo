<?php
// Function to merge sections.xml and products.xml into output.xml
function mergeCatalog($sectionsXmlPath, $productsXmlPath)
{
    // Load XML files
    $sectionsXml = simplexml_load_file($sectionsXmlPath);
    $productsXml = simplexml_load_file($productsXmlPath);

    // Create output XML structure
    $outputXml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><ЭлементыКаталога><Разделы></Разделы></ЭлементыКаталога>');

    // Process each section
    foreach ($sectionsXml->Раздел as $section) {
        $sectionId = (string) $section->Ид;

        // Add section to output
        $outputSection = $outputXml->Разделы->addChild('Раздел');
        $outputSection->addChild('Ид', $sectionId);
        $outputSection->addChild('Наименование', (string) $section->Наименование);

        // Add empty Товары node to the section
        $outputProducts = $outputSection->addChild('Товары');

        // Find products for this section
        if (isset($productsXml->Товар)) {
            foreach ($productsXml->Товар as $product) {
                // Check if this product belongs to this section
                $belongsToSection = false;
                if (isset($product->Разделы->ИдРаздела)) {
                    foreach ($product->Разделы->ИдРаздела as $productSectionId) {
                        if ((string) $productSectionId === $sectionId) {
                            $belongsToSection = true;
                            break;
                        }
                    }
                }

                // If product belongs to this section, add it
                if ($belongsToSection) {
                    $outputProduct = $outputProducts->addChild('Товар');
                    $outputProduct->addChild('Ид', (string) $product->Ид);
                    $outputProduct->addChild('Наименование', (string) $product->Наименование);
                    $outputProduct->addChild('Артикул', (string) $product->Артикул);
                }
            }
        }
    }

    // Save to output file
    $dom = new DOMDocument('1.0', 'UTF-8');
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    $dom->loadXML($outputXml->asXML());

    return $dom->saveXML();
}

// Testing framework to run against all test cases in ./test directory
function runTests()
{
    $testDir = './test';

    // Check if test directory exists
    if (!is_dir($testDir)) {
        echo "Error: Test directory '$testDir' not found\n";
        return false;
    }

    // Get all section files to determine test case numbers
    $sectionFiles = glob("$testDir/*_sections.xml");

    if (empty($sectionFiles)) {
        echo "No test files found in '$testDir'\n";
        return false;
    }

    // Extract test case numbers
    $testCases = [];
    foreach ($sectionFiles as $file) {
        preg_match('/(\d+)_sections\.xml$/', $file, $matches);
        if (isset($matches[1])) {
            $testCases[] = $matches[1];
        }
    }

    sort($testCases);
    echo "Found " . count($testCases) . " test cases: " . implode(', ', $testCases) . "\n";

    $allTestsPassed = true;

    foreach ($testCases as $testNum) {
        $sectionsXmlPath = "$testDir/{$testNum}_sections.xml";
        $productsXmlPath = "$testDir/{$testNum}_products.xml";
        $expectedOutputPath = "$testDir/{$testNum}_result.xml";

        // Check if all required files exist
        if (!file_exists($sectionsXmlPath)) {
            echo "Test $testNum: SKIPPED - Missing sections file\n";
            continue;
        }

        if (!file_exists($productsXmlPath)) {
            echo "Test $testNum: SKIPPED - Missing products file\n";
            continue;
        }

        if (!file_exists($expectedOutputPath)) {
            echo "Test $testNum: SKIPPED - Missing expected output file\n";
            continue;
        }

        // Run the merge
        $actualOutput = mergeCatalog($sectionsXmlPath, $productsXmlPath);
        $expectedOutput = file_get_contents($expectedOutputPath);

        // Normalize whitespace and line endings for comparison
        $normalizedActual = normalizeXml($actualOutput);
        $normalizedExpected = normalizeXml($expectedOutput);

        // Compare outputs
        if ($normalizedActual === $normalizedExpected) {
            echo "Test $testNum: PASSED\n";
        } else {
            echo "Test $testNum: FAILED\n";
            $allTestsPassed = false;

            // Save output for inspection
            file_put_contents("output_$testNum.xml", $actualOutput);
            echo "Output saved to output_$testNum.xml for inspection\n";

            // Show diff (limited to first few differences)
            $diffLimit = 200;
            $diff = substr(diff($normalizedExpected, $normalizedActual), 0, $diffLimit);
            if (strlen($diff) >= $diffLimit) {
                $diff .= "... (truncated)";
            }
            echo "Differences: $diff\n";
        }
    }

    if ($allTestsPassed) {
        echo "All tests passed!\n";
    } else {
        echo "Some tests failed. Please check the output above.\n";
    }

    return $allTestsPassed;
}

// Helper function to normalize XML for comparison
function normalizeXml($xml)
{
    // Remove XML declaration
    $xml = preg_replace('/<\?xml[^>]+\?>/', '', $xml);

    // Normalize whitespace
    $xml = preg_replace('/\s+/', ' ', $xml);
    $xml = trim($xml);

    return $xml;
}

// Helper function to show differences
function diff($str1, $str2)
{
    $str1 = str_split($str1);
    $str2 = str_split($str2);
    $len1 = count($str1);
    $len2 = count($str2);
    $max = min($len1, $len2);

    $result = '';
    for ($i = 0; $i < $max; $i++) {
        if ($str1[$i] !== $str2[$i]) {
            $result .= "at position $i: expected '{$str1[$i]}', got '{$str2[$i]}'\n";
        }
    }

    if ($len1 !== $len2) {
        $result .= "Length mismatch: expected $len1, got $len2\n";
    }

    return $result;
}

// Main execution
if (count($argv) > 1 && $argv[1] === 'run') {
    // If script is run with 'run' argument, merge sections.xml and products.xml in current directory
    $output = mergeCatalog('sections.xml', 'products.xml');
    file_put_contents('output.xml', $output);
    echo "Merged XML saved to output.xml\n";
} else {
    // Run tests
    runTests();
}
?>